package de.programmierenlernenhq.panzerhq;

public class EnemieTank extends Tank {

	public EnemieTank(Coordinate position, double width, double height,double movingAngle, double movingDistance) 
	{
		super(position, width, height, movingAngle, movingDistance);
	
	}

}
