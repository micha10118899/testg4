package de.programmierenlernenhq.panzerhq;

/**
 *
 * @author ProgrammierenLernenHQ
 */
public class PanzerHQ {

    
    public static void main(String[] args) {
        
        new GameWindow();
    }
}